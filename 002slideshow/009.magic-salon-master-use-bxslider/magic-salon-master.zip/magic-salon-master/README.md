# magic-salon
This is a magic salon website built with HTML5, CSS3, JavaScript, jQuery, Animations, Slider and so on.

## View Demo
http://magicsalon.herokuapp.com/
